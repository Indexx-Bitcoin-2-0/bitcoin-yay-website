# indexx-pay-js-sdk

Embeddable browser SDK for [Indexx Pay](../indexx-pay-mobile)'s USDXX API on
`indexx-exchange-backend` (`test` branch — Tier 1/2 aren't deployed to
production yet). Ships as ESM (`dist/index.mjs`), CJS (`dist/index.cjs`), and
a `<script>`-tag-loadable global (`dist/index.global.js`, `window.IndexxPaySDK`).

Two pieces:

- **`IndexxPayClient`** — every endpoint gated by the backend's
  `requireWalletOwner` middleware: balance, peer-to-peer send, payment
  requests, USDXX⇄BTCY conversion, the withdrawal off-ramp, and the raw Tier 2
  buy-checkout calls.
- **`mountBuyUsdxxWidget(container, options)`** — a drop-in "Buy USDXX"
  checkout (amount field, Stripe Elements Payment Element, PayPal redirect
  button) built on top of `IndexxPayClient`, mirroring `indexx_pay` web's own
  `BuyUsdxxModal.tsx` but framework-agnostic.

## Two ways to use it

- **Signed-in users** (a site that already holds the user's Indexx Pay JWT via
  SSO): `IndexxPayClient` + `mountBuyUsdxxWidget()`. Every method needs
  `getToken()`.
- **Anonymous customers** (Shop, Academy, ...): hosted checkout. Your server
  creates a session with `indexx-pay-server-sdk`'s `createCheckoutSession()`
  and gives the browser the `checkoutUrl`; here you call
  `redirectToCheckout(checkoutUrl)`, then `getCheckoutSession(baseUrl, id)` on
  your success/cancel page for a status hint. No user token involved. Fulfil
  orders from your server, never from the browser's report.

## Install

Not published yet (`private: true` until that's a deliberate decision).

```json
{ "dependencies": { "indexx-pay-js-sdk": "file:../indexx-pay-js-sdk" } }
```

Or via a plain `<script>` tag, no bundler needed:

```html
<script src="/vendor/indexx-pay-js-sdk/index.global.js"></script>
<script>
  const client = new IndexxPaySDK.IndexxPayClient({
    baseUrl: "https://test.api.v1.indexx.ai",
    getToken: () => myStoredIndexxJwt,
  });
</script>
```

## Usage (bundler / ESM)

```ts
import { IndexxPayClient, mountBuyUsdxxWidget } from "indexx-pay-js-sdk";

const client = new IndexxPayClient({
  baseUrl: "https://test.api.v1.indexx.ai",
  getToken: () => currentUser.indexxJwt,
});

const { balance } = await client.getBalance(currentUser.email);

mountBuyUsdxxWidget("#buy-usdxx", {
  client,
  stripePublishableKey: "pk_test_...",
  onSuccess: (result) => console.log("New balance:", result.balance),
  onError: (err) => console.error(err),
});
```

Requires `@stripe/stripe-js` as a peer dependency when consumed via
ESM/CJS (the `dist/index.global.js` build bundles it in, since a plain
`<script>` tag has no package resolution to rely on).

The widget auto-detects a PayPal return on mount and confirms the purchase
immediately instead of showing an empty form again. It also handles the
return-URL convention itself: PayPal only appends `token=<orderId>` to
whatever `returnUrl`/`cancelUrl` you passed, it doesn't mark which case
you're in, so the widget bakes in a `paypal=success` / `paypal=cancelled`
query param on top of your URL when it calls `createPaypalTopUp` (matching
indexx_pay web's own `/dashboard?paypal=success&token=...` convention) —
you don't need to add that yourself. If you call `IndexxPayClient.createPaypalTopUp`
directly instead of using the widget, you do need to bake that marker in
yourself for `readPaypalReturn()` to recognize the return.

## Scripts

```bash
npm run build       # types + esm + cjs + global bundles into dist/
npm run typecheck   # tsc --noEmit
npm test            # builds, then runs test/*.test.ts against dist/index.mjs with a mocked fetch
```

`test/*.test.ts` cover `IndexxPayClient` and the PayPal return-URL parsing
(pure logic, no DOM needed). The DOM-manipulating widget itself was verified
separately by loading the actual compiled `dist/index.global.js` into a jsdom
document via a real `<script>` element and driving it end-to-end (render,
validation, PayPal order creation, unmount, and the auto-confirm-on-return
flow) — not committed as an automated test since it needs a temporary jsdom
dependency this package doesn't otherwise carry, but every behavior it
checked passed against the real build output before this shipped.

## Status

Covers Tier 2 "buy USDXX" (Stripe + PayPal) and the end-user-scoped Tier 1
surface (balance, send, payment requests, BTCY conversion, withdrawal), same
coverage as `indexx-pay-server-sdk`'s `IndexxPayUserClient` but for the
browser. Does not include a server-to-server client (that's
`indexx-pay-server-sdk`'s `IndexxPayServiceClient` — never ship a service API
key to a browser).
